package com.jatools.dwr.sys;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.directwebremoting.annotations.RemoteMethod;
import org.directwebremoting.annotations.RemoteProxy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.jatools.common.CommonUtil;
import com.jatools.service.sys.DictService;
import com.jatools.vo.sys.Dict;
import com.jatools.vo.sys.DictEntry;
import com.jatools.vo.sys.DictItem;
import com.jatools.vo.util.SelectorOption;
import com.jatools.web.cache.DictCache;

@Controller
@RemoteProxy(name="DictDwr")
public class DictDwr {
	
	private static Logger logger = Logger.getLogger(DictDwr.class);
	
	@Autowired
	private DictService dictService;
	
	/**
	 * 根据数据字典名称获取数据字典项
	 */
	@RemoteMethod
	public List<SelectorOption> getDictsForSlt(String name){
		List<Dict> dictList = DictCache.getInstance().getDicts(name);
		if(null == dictList || dictList.size()<1)
			return null;
		List<SelectorOption> sltList = new ArrayList<SelectorOption>();
		for(Dict dict : dictList){
			sltList.add(new SelectorOption(dict.getItemKey(), dict.getItemValue()));
		}
		return sltList;
	}
	/**
	 * 删除数据字典
	 * @param entryCode
	 * @param req
	 * @return
	 */
	@RemoteMethod
	public String deleteDictEntry(String entryCode, HttpServletRequest req){
		try {
			String userid = CommonUtil.getSessionUserId(req);
			dictService.deleteDictEntry(entryCode, userid);
			DictCache.getInstance().refresh();
		} catch (Exception e) {
			logger.error(e);
			return "删除数据字典出错";
		}
		return null;
	}
	/**
	 * 修改数据字典
	 * @param entry
	 * @param list
	 * @param req
	 * @return
	 */
	@RemoteMethod
	public String updateDictEntry(DictEntry entry, List<DictItem> list, HttpServletRequest req){
		String userid = CommonUtil.getSessionUserId(req);
		dictService.updateDictEntry(entry, list, userid);
		DictCache.getInstance().refresh();
		return null;
	}
	/**
	 * 保存数据字典
	 * @param entry
	 * @param list
	 * @param req
	 * @return
	 */
	@RemoteMethod
	public String saveDictEntry(DictEntry entry, List<DictItem> list, HttpServletRequest req){
		String userid = CommonUtil.getSessionUserId(req);
		dictService.saveDictEntry(entry, list, userid);
		DictCache.getInstance().refresh();
		return null;
	}
}
