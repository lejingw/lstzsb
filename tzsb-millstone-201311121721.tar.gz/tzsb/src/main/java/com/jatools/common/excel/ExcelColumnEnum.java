package com.jatools.common.excel;

public enum ExcelColumnEnum {
	STRING_COLUMN,
	NUMBER_COLUMN,
	FLOAT_COLUMN,
	DATE_COLUMN
}
