package com.jatools.common.excel;

import com.jatools.common.PropertyUtil;

public class ExcelRowData {
	private String seqId;
	private int sheetIndex;
	private int rowIndex;
	private String result;
	
	private String col0;
	private String col1;
	private String col2;
	private String col3;
	private String col4;
	private String col5;
	private String col6;
	private String col7;
	private String col8;
	private String col9;
	private String col10;
	private String col11;
	private String col12;
	private String col13;
	private String col14;
	private String col15;
	private String col16;
	private String col17;
	private String col18;
	private String col19;
	private String col20;
	private String col21;
	private String col22;
	private String col23;
	private String col24;
	private String col25;
	private String col26;
	private String col27;
	private String col28;
	private String col29;
	private String col30;
	private String col31;
	private String col32;
	private String col33;
	private String col34;
	private String col35;
	private String col36;
	private String col37;
	private String col38;
	private String col39;
	private String col40;
	private String col41;
	private String col42;
	private String col43;
	private String col44;
	private String col45;
	private String col46;
	private String col47;
	private String col48;
	private String col49;
	private String col50;
	private String col51;
	private String col52;
	private String col53;
	private String col54;
	private String col55;
	private String col56;
	private String col57;
	private String col58;
	private String col59;
	private String col60;
	private String col61;
	private String col62;
	private String col63;
	private String col64;
	private String col65;
	private String col66;
	private String col67;
	private String col68;
	private String col69;
	private String col70;
	private String col71;
	private String col72;
	private String col73;
	private String col74;
	private String col75;
	private String col76;
	private String col77;
	private String col78;
	private String col79;
	private String col80;
	private String col81;
	private String col82;
	private String col83;
	private String col84;
	private String col85;
	private String col86;
	private String col87;
	private String col88;
	private String col89;
	private String col90;
	private String col91;
	private String col92;
	private String col93;
	private String col94;
	private String col95;
	private String col96;
	private String col97;
	private String col98;
	private String col99;

	public String getSeqId() {
		return seqId;
	}

	public void setSeqId(String seqId) {
		this.seqId = seqId;
	}

	public int getSheetIndex() {
		return sheetIndex;
	}

	public void setSheetIndex(int sheetIndex) {
		this.sheetIndex = sheetIndex;
	}

	public int getRowIndex() {
		return rowIndex;
	}

	public void setRowIndex(int rowIndex) {
		this.rowIndex = rowIndex;
	}

	public String getCol0() {
		return col0;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public void setCol0(String col0) {
		this.col0 = col0;
	}

	public String getCol1() {
		return col1;
	}

	public void setCol1(String col1) {
		this.col1 = col1;
	}

	public String getCol2() {
		return col2;
	}

	public void setCol2(String col2) {
		this.col2 = col2;
	}

	public String getCol3() {
		return col3;
	}

	public void setCol3(String col3) {
		this.col3 = col3;
	}

	public String getCol4() {
		return col4;
	}

	public void setCol4(String col4) {
		this.col4 = col4;
	}

	public String getCol5() {
		return col5;
	}

	public void setCol5(String col5) {
		this.col5 = col5;
	}

	public String getCol6() {
		return col6;
	}

	public void setCol6(String col6) {
		this.col6 = col6;
	}

	public String getCol7() {
		return col7;
	}

	public void setCol7(String col7) {
		this.col7 = col7;
	}

	public String getCol8() {
		return col8;
	}

	public void setCol8(String col8) {
		this.col8 = col8;
	}

	public String getCol9() {
		return col9;
	}

	public void setCol9(String col9) {
		this.col9 = col9;
	}

	public String getCol10() {
		return col10;
	}

	public void setCol10(String col10) {
		this.col10 = col10;
	}

	public String getCol11() {
		return col11;
	}

	public void setCol11(String col11) {
		this.col11 = col11;
	}

	public String getCol12() {
		return col12;
	}

	public void setCol12(String col12) {
		this.col12 = col12;
	}

	public String getCol13() {
		return col13;
	}

	public void setCol13(String col13) {
		this.col13 = col13;
	}

	public String getCol14() {
		return col14;
	}

	public void setCol14(String col14) {
		this.col14 = col14;
	}

	public String getCol15() {
		return col15;
	}

	public void setCol15(String col15) {
		this.col15 = col15;
	}

	public String getCol16() {
		return col16;
	}

	public void setCol16(String col16) {
		this.col16 = col16;
	}

	public String getCol17() {
		return col17;
	}

	public void setCol17(String col17) {
		this.col17 = col17;
	}

	public String getCol18() {
		return col18;
	}

	public void setCol18(String col18) {
		this.col18 = col18;
	}

	public String getCol19() {
		return col19;
	}

	public void setCol19(String col19) {
		this.col19 = col19;
	}

	public String getCol20() {
		return col20;
	}

	public void setCol20(String col20) {
		this.col20 = col20;
	}

	public String getCol21() {
		return col21;
	}

	public void setCol21(String col21) {
		this.col21 = col21;
	}

	public String getCol22() {
		return col22;
	}

	public void setCol22(String col22) {
		this.col22 = col22;
	}

	public String getCol23() {
		return col23;
	}

	public void setCol23(String col23) {
		this.col23 = col23;
	}

	public String getCol24() {
		return col24;
	}

	public void setCol24(String col24) {
		this.col24 = col24;
	}

	public String getCol25() {
		return col25;
	}

	public void setCol25(String col25) {
		this.col25 = col25;
	}

	public String getCol26() {
		return col26;
	}

	public void setCol26(String col26) {
		this.col26 = col26;
	}

	public String getCol27() {
		return col27;
	}

	public void setCol27(String col27) {
		this.col27 = col27;
	}

	public String getCol28() {
		return col28;
	}

	public void setCol28(String col28) {
		this.col28 = col28;
	}

	public String getCol29() {
		return col29;
	}

	public void setCol29(String col29) {
		this.col29 = col29;
	}

	public String getCol30() {
		return col30;
	}

	public void setCol30(String col30) {
		this.col30 = col30;
	}

	public String getCol31() {
		return col31;
	}

	public void setCol31(String col31) {
		this.col31 = col31;
	}

	public String getCol32() {
		return col32;
	}

	public void setCol32(String col32) {
		this.col32 = col32;
	}

	public String getCol33() {
		return col33;
	}

	public void setCol33(String col33) {
		this.col33 = col33;
	}

	public String getCol34() {
		return col34;
	}

	public void setCol34(String col34) {
		this.col34 = col34;
	}

	public String getCol35() {
		return col35;
	}

	public void setCol35(String col35) {
		this.col35 = col35;
	}

	public String getCol36() {
		return col36;
	}

	public void setCol36(String col36) {
		this.col36 = col36;
	}

	public String getCol37() {
		return col37;
	}

	public void setCol37(String col37) {
		this.col37 = col37;
	}

	public String getCol38() {
		return col38;
	}

	public void setCol38(String col38) {
		this.col38 = col38;
	}

	public String getCol39() {
		return col39;
	}

	public void setCol39(String col39) {
		this.col39 = col39;
	}

	public String getCol40() {
		return col40;
	}

	public void setCol40(String col40) {
		this.col40 = col40;
	}

	public String getCol41() {
		return col41;
	}

	public void setCol41(String col41) {
		this.col41 = col41;
	}

	public String getCol42() {
		return col42;
	}

	public void setCol42(String col42) {
		this.col42 = col42;
	}

	public String getCol43() {
		return col43;
	}

	public void setCol43(String col43) {
		this.col43 = col43;
	}

	public String getCol44() {
		return col44;
	}

	public void setCol44(String col44) {
		this.col44 = col44;
	}

	public String getCol45() {
		return col45;
	}

	public void setCol45(String col45) {
		this.col45 = col45;
	}

	public String getCol46() {
		return col46;
	}

	public void setCol46(String col46) {
		this.col46 = col46;
	}

	public String getCol47() {
		return col47;
	}

	public void setCol47(String col47) {
		this.col47 = col47;
	}

	public String getCol48() {
		return col48;
	}

	public void setCol48(String col48) {
		this.col48 = col48;
	}

	public String getCol49() {
		return col49;
	}

	public void setCol49(String col49) {
		this.col49 = col49;
	}

	public String getCol50() {
		return col50;
	}

	public void setCol50(String col50) {
		this.col50 = col50;
	}

	public String getCol51() {
		return col51;
	}

	public void setCol51(String col51) {
		this.col51 = col51;
	}

	public String getCol52() {
		return col52;
	}

	public void setCol52(String col52) {
		this.col52 = col52;
	}

	public String getCol53() {
		return col53;
	}

	public void setCol53(String col53) {
		this.col53 = col53;
	}

	public String getCol54() {
		return col54;
	}

	public void setCol54(String col54) {
		this.col54 = col54;
	}

	public String getCol55() {
		return col55;
	}

	public void setCol55(String col55) {
		this.col55 = col55;
	}

	public String getCol56() {
		return col56;
	}

	public void setCol56(String col56) {
		this.col56 = col56;
	}

	public String getCol57() {
		return col57;
	}

	public void setCol57(String col57) {
		this.col57 = col57;
	}

	public String getCol58() {
		return col58;
	}

	public void setCol58(String col58) {
		this.col58 = col58;
	}

	public String getCol59() {
		return col59;
	}

	public void setCol59(String col59) {
		this.col59 = col59;
	}

	public String getCol60() {
		return col60;
	}

	public void setCol60(String col60) {
		this.col60 = col60;
	}

	public String getCol61() {
		return col61;
	}

	public void setCol61(String col61) {
		this.col61 = col61;
	}

	public String getCol62() {
		return col62;
	}

	public void setCol62(String col62) {
		this.col62 = col62;
	}

	public String getCol63() {
		return col63;
	}

	public void setCol63(String col63) {
		this.col63 = col63;
	}

	public String getCol64() {
		return col64;
	}

	public void setCol64(String col64) {
		this.col64 = col64;
	}

	public String getCol65() {
		return col65;
	}

	public void setCol65(String col65) {
		this.col65 = col65;
	}

	public String getCol66() {
		return col66;
	}

	public void setCol66(String col66) {
		this.col66 = col66;
	}

	public String getCol67() {
		return col67;
	}

	public void setCol67(String col67) {
		this.col67 = col67;
	}

	public String getCol68() {
		return col68;
	}

	public void setCol68(String col68) {
		this.col68 = col68;
	}

	public String getCol69() {
		return col69;
	}

	public void setCol69(String col69) {
		this.col69 = col69;
	}

	public String getCol70() {
		return col70;
	}

	public void setCol70(String col70) {
		this.col70 = col70;
	}

	public String getCol71() {
		return col71;
	}

	public void setCol71(String col71) {
		this.col71 = col71;
	}

	public String getCol72() {
		return col72;
	}

	public void setCol72(String col72) {
		this.col72 = col72;
	}

	public String getCol73() {
		return col73;
	}

	public void setCol73(String col73) {
		this.col73 = col73;
	}

	public String getCol74() {
		return col74;
	}

	public void setCol74(String col74) {
		this.col74 = col74;
	}

	public String getCol75() {
		return col75;
	}

	public void setCol75(String col75) {
		this.col75 = col75;
	}

	public String getCol76() {
		return col76;
	}

	public void setCol76(String col76) {
		this.col76 = col76;
	}

	public String getCol77() {
		return col77;
	}

	public void setCol77(String col77) {
		this.col77 = col77;
	}

	public String getCol78() {
		return col78;
	}

	public void setCol78(String col78) {
		this.col78 = col78;
	}

	public String getCol79() {
		return col79;
	}

	public void setCol79(String col79) {
		this.col79 = col79;
	}

	public String getCol80() {
		return col80;
	}

	public void setCol80(String col80) {
		this.col80 = col80;
	}

	public String getCol81() {
		return col81;
	}

	public void setCol81(String col81) {
		this.col81 = col81;
	}

	public String getCol82() {
		return col82;
	}

	public void setCol82(String col82) {
		this.col82 = col82;
	}

	public String getCol83() {
		return col83;
	}

	public void setCol83(String col83) {
		this.col83 = col83;
	}

	public String getCol84() {
		return col84;
	}

	public void setCol84(String col84) {
		this.col84 = col84;
	}

	public String getCol85() {
		return col85;
	}

	public void setCol85(String col85) {
		this.col85 = col85;
	}

	public String getCol86() {
		return col86;
	}

	public void setCol86(String col86) {
		this.col86 = col86;
	}

	public String getCol87() {
		return col87;
	}

	public void setCol87(String col87) {
		this.col87 = col87;
	}

	public String getCol88() {
		return col88;
	}

	public void setCol88(String col88) {
		this.col88 = col88;
	}

	public String getCol89() {
		return col89;
	}

	public void setCol89(String col89) {
		this.col89 = col89;
	}

	public String getCol90() {
		return col90;
	}

	public void setCol90(String col90) {
		this.col90 = col90;
	}

	public String getCol91() {
		return col91;
	}

	public void setCol91(String col91) {
		this.col91 = col91;
	}

	public String getCol92() {
		return col92;
	}

	public void setCol92(String col92) {
		this.col92 = col92;
	}

	public String getCol93() {
		return col93;
	}

	public void setCol93(String col93) {
		this.col93 = col93;
	}

	public String getCol94() {
		return col94;
	}

	public void setCol94(String col94) {
		this.col94 = col94;
	}

	public String getCol95() {
		return col95;
	}

	public void setCol95(String col95) {
		this.col95 = col95;
	}

	public String getCol96() {
		return col96;
	}

	public void setCol96(String col96) {
		this.col96 = col96;
	}

	public String getCol97() {
		return col97;
	}

	public void setCol97(String col97) {
		this.col97 = col97;
	}

	public String getCol98() {
		return col98;
	}

	public void setCol98(String col98) {
		this.col98 = col98;
	}

	public String getCol99() {
		return col99;
	}

	public void setCol99(String col99) {
		this.col99 = col99;
	}

	public ExcelRowData() {
	}

	public ExcelRowData(int sheetIndex, int rowIndex) {
		this.sheetIndex = sheetIndex;
		this.rowIndex = rowIndex;
	}

	public void setColValue(int cellIndex, String value) {
		try {
			PropertyUtil.setProperty(this, "col" + cellIndex, value);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("设置字段[col" + cellIndex + "]出错");
		}
	}

	public String toString() {
		return sheetIndex + ":" + rowIndex + 
				"\tcol0:" + col0+
				"\tcol1:" + col1+
				"\tcol2:" + col2+
				"\tcol3:" + col3+
				"\tcol4:" + col4+
				"\tcol5:" + col5+
				"\tcol6:" + col6+
				"\tcol7:" + col7+
				"\tcol8:" + col8+
				"\tcol9:" + col9+
				"\tcol10:" + col10+
				"\tcol11:" + col11+
				"\tcol12:" + col12+
				"\tcol13:" + col13+
				"\tcol14:" + col14+
				"\tcol15:" + col15+
				"\tcol16:" + col16+
				"\tcol17:" + col17+
				"\tcol18:" + col18+
				"\tcol19:" + col19+
				"\tcol20:" + col20+
				"\tcol21:" + col21+
				"\tcol22:" + col22+
				"\tcol23:" + col23+
				"\tcol24:" + col24+
				"\tcol25:" + col25+
				"\tcol26:" + col26+
				"\tcol27:" + col27+
				"\tcol28:" + col28+
				"\tcol29:" + col29+
				"\tcol30:" + col30+
				"\tcol31:" + col31+
				"\tcol32:" + col32+
				"\tcol33:" + col33+
				"\tcol34:" + col34+
				"\tcol35:" + col35+
				"\tcol36:" + col36+
				"\tcol37:" + col37+
				"\tcol38:" + col38+
				"\tcol39:" + col39+
				"\tcol40:" + col40+
				"\tcol41:" + col41+
				"\tcol42:" + col42+
				"\tcol43:" + col43+
				"\tcol44:" + col44+
				"\tcol45:" + col45+
				"\tcol46:" + col46+
				"\tcol47:" + col47+
				"\tcol48:" + col48+
				"\tcol49:" + col49+
				"\tcol50:" + col50+
				"\tcol51:" + col51+
				"\tcol52:" + col52+
				"\tcol53:" + col53+
				"\tcol54:" + col54+
				"\tcol55:" + col55+
				"\tcol56:" + col56+
				"\tcol57:" + col57+
				"\tcol58:" + col58+
				"\tcol59:" + col59+
				"\tcol60:" + col60+
				"\tcol61:" + col61+
				"\tcol62:" + col62+
				"\tcol63:" + col63+
				"\tcol64:" + col64+
				"\tcol65:" + col65+
				"\tcol66:" + col66+
				"\tcol67:" + col67+
				"\tcol68:" + col68+
				"\tcol69:" + col69+
				"\tcol70:" + col70+
				"\tcol71:" + col71+
				"\tcol72:" + col72+
				"\tcol73:" + col73+
				"\tcol74:" + col74+
				"\tcol75:" + col75+
				"\tcol76:" + col76+
				"\tcol77:" + col77+
				"\tcol78:" + col78+
				"\tcol79:" + col79+
				"\tcol80:" + col80+
				"\tcol81:" + col81+
				"\tcol82:" + col82+
				"\tcol83:" + col83+
				"\tcol84:" + col84+
				"\tcol85:" + col85+
				"\tcol86:" + col86+
				"\tcol87:" + col87+
				"\tcol88:" + col88+
				"\tcol89:" + col89+
				"\tcol90:" + col90+
				"\tcol91:" + col91+
				"\tcol92:" + col92+
				"\tcol93:" + col93+
				"\tcol94:" + col94+
				"\tcol95:" + col95+
				"\tcol96:" + col96+
				"\tcol97:" + col97+
				"\tcol98:" + col98+
				"\tcol99:" + col99;
	}
}
