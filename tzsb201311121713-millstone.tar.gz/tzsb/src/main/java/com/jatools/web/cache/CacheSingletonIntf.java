package com.jatools.web.cache;

public interface CacheSingletonIntf {
	public String getNameById(String id);
	public String getRefreshTime();
}
