package com.jatools.common.constant;

public class ParameterConstant {
	public static final String PIC_BASE_PATH_OUT = "picBasicPath";
}
